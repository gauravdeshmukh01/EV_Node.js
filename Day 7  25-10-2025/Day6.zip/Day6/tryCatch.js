try {
    doSomething();
} catch (e) {
    console.log("there is an error");
}

function doSomething(){
    console.log("everything is fine");
}




