import {customError} from "./CustomError.js"
throw new customError("this is custom error")