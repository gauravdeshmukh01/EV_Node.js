// const errr=new Error("some thing went wrong");
// // console.log(errr.message);

// throw new Error("error error bhago yahase error error");


// try {
//     throw new Error("something went wrong");
// }catch(err){
//     console.error("error is:", err.message);
// }


// function task(cb) {
//     setTimeout(() => { cb(null, "hello"); }, 0);
// }

// task((err, data) => {
//     if (err) throw err;       
//     else console.log("callback data:", data);
// });


// function dosomething(){
//     console.log("hello");
// }

// process.on('uncaughtException', (e)=>{
//     console.log("there is an error",e.message);
//     process.exit(1)
// })

// dosomething();

const promise=new Promise((resolve,reject)=>{
    if(true){
        resolve("Hurray program working");
    } else {
        reject("there is an error");
    }
});

promise.then((val)=>{console.log(val);}).catch((err)=>{console.log("error",err);});