const M = require('./class2.js');
// // M.greet('Pushkar');
// // M.display('Pushkar Patil');

// // let r=M.double(10);
// // let p=M.square(2);

// // console.log(p,r);

// let a=M.add(10,10);
// let b=M.sub(5,2);
// let c=M.mul(10,10);
// let d=M.div(5,2);
// console.log(a,b,c,d);

// const Student = require('./student.js');

// const s1 = new Student(1, 'pushkar', 'IT');
// s1.display();

// const s1 = M.increment();
// const s2 = M.increment();
// console.log(s1);
// console.log(s2);

// console.log(require.cache);


// delete require.cache[require.resolve('./class2.js')]