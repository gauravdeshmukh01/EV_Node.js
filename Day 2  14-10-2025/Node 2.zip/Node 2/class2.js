// function greet(name) {
//     console.log('hello ' + name);
// }

// function display(name) {
//     console.log(name);
// }

// module.exports = { greet, display };


// function double(num){
//     return 2*num;
// }

// function square(num){
//     return num * num;
// }

// function add(num1,num2){
//     return num1 + num2;
// }

// function sub(num1,num2){
//     return num1 - num2;
// }

// function mul(num1,num2){
//     return num1 * num2;
// }

// function div(num1,num2){
//     return num1 / num2;
// }

// module.exports = { add,sub,mul,div};

// let count = 0;

// function increment() {
//   count++;
//   return count;
// }

// console.log('counter.js is loaded');
// module.exports = { increment };



// const os=require('os');

// console.log('Platform',os.platform());
// console.log('Architecture',os.arch());
// console.log('Total Memory',os.totalmem());
// console.log('Free Memory',os.freemem());

// console.log(os.type());

// const fs=require('fs');

// fs.writeFileSync('hello.txt','hello welcome to nodejs module class');
// fs.readFileSync('hello.txt','utf-8');


// console.log(fs.readFileSync('hello.txt','utf-8'));


// const http = require('http');

// const server = http.createServer((req, res) => {
//     res.writeHead(200, { 'Content-Type': 'text/plain' });
//     res.end('Hello from Node.js server');
// });

// server.listen(3000, () => {
//     console.log('Server running on http://localhost:3000');
// });


// const c = require('chalk');
// const chalk = new c.Chalk();
// console.log(chalk.green("skjbs"))  ;
// console.log(chalk.green('Hello'));
// console.log(chalk.red.bold('welcome'));
// console.log(chalk.blue.underline('learning throd party modules'));


// const axios = require('axios');
// const url = 'https://jsonplaceholder.typicode.com/users';

// async function fetchUsers() {
//     try {
//         const response = await axios.get(url);
//         const users = response.data;

//         console.log('users fetched from api');
//         console.log(users);
//     } catch (error) {
//         console.log('error fetching data', error.message);
//     }
// }
// fetchUsers();