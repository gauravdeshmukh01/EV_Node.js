// class Std{
//     constructor(id, name, course) {
//         this.id = id;
//         this.name = name;
//         this.course = course;
//     }

//     display() {
//         console.log(`id: ${this.id}, Name: ${this.name}, course: ${this.course}`);
//     }
// }
// module.exports = Std;