function add(a,b){
    return a+b;
}

function sub(a,b){
    return a-b;
}

function mult(a,b){
    return a*b;
}

function division(a,b){
    return a/b;
}


module.exports = {add, sub, mult, division};