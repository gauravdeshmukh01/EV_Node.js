
function double(num){
    return 2*num;
}

function square(num){
    return num*num;
}

module.exports = {double, square};