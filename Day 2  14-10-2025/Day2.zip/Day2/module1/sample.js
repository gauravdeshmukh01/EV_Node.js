function greet(name){
    console.log('Hello '+ name );
}

function display(){
    console.log("Welcome!")
}

module.exports = {greet, display};