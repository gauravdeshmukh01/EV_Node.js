const g = require('../module1/sample');

g.greet("Virat");
g.display();

