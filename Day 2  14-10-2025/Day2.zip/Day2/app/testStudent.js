const Student = require("../module1/student");
const stud = new Student(1, "Virat", "IT");
stud.display(); 


