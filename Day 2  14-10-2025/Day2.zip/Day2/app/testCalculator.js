const calc = require('../module1/calculator')

console.log(calc.add(5,7));
console.log(calc.sub(10,5));
console.log(calc.mult(5,2));
console.log(calc.division(10,2));