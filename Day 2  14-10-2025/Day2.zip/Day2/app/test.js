const mat = require('../module1/mathtool')

console.log(mat.double(3));
console.log(mat.square(4));




