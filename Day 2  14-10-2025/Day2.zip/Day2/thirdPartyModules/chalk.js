const c = require('chalk');
const chalk = new c.Chalk();
// console.log(chalk.green("skjbs"))  

console.log(chalk.green('Hello'))
console.log(chalk.red.bold('Welcome'))
console.log(chalk.blue.underline('learning third party modules'))


