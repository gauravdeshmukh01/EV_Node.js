const os=require('os');


console.log('Platform',os.platform());
console.log('Architecture',os.arch());
console.log('total memory',os.totalmem());
console.log('free Memory',os.freemem());