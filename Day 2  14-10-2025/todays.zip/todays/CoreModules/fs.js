const fs=require('fs')

fs.writeFileSync('first.txt',"Hello , welcome to fs module");


const fdata=fs.readFileSync('first.txt','utf-8');

console.log(fdata);