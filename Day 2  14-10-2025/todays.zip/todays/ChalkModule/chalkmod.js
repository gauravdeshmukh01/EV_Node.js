// for version 5 or above chalk support only dynamic import as below does not support require method
import chalk from "chalk";

console.log(chalk.green('Hello'));

console.log(chalk.red.bold('Welcome'));

console.log(chalk.blue.underline('Learning third party module'))