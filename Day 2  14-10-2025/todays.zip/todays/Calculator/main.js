const cal=require('./calculator')

console.log(cal.add(1,2));
console.log(cal.sub(5,2));
console.log(cal.mul(4,5));
console.log(cal.div(10,5));