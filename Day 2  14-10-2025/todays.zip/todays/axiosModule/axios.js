const axios=require('axios')
const url='http://jsonplaceholder.typicode.com/users'

async function fetchUsers()
{
    try{
        const response=await axios.get(url)
        const users=response.data;

        console.log('Users fetched from api')
        console.log(users)
    }catch(err)
    {
        console.log(err);
    }
}


fetchUsers();