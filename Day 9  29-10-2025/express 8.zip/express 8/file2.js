const express = require('express');
const path = require('path');
const app = express();
const port = 3025;

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'src', 'views', 'home.html'));
});

app.get('/about', (req, res) => {
  res.sendFile(path.join(__dirname, 'src', 'views', 'about.html'));
});

app.get('/user', (req, res) => {
  res.sendFile(path.join(__dirname, 'src', 'views', 'user.html'));
});

app.get('/userinfo', (req, res) => {
    const { username, id } = req.query;
    res.json({
      name: username,
      userId: id,
    });
  });
  
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
