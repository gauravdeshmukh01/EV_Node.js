// const express=require('express');
// const path = require('path');
// const app=express();


// const port=3025;

// app.get('/home', (req, res) => {
//     console.log('Your home.html');
//     res.sendFile(path.join(__dirname, 'src', 'views', 'home.html'));
// });

// app.get('/about', (req, res) => {
//     console.log('your about.html');
//     res.sendFile(path.join(__dirname, 'src', 'views', 'about.html'));
// });


// app.listen(port,()=>{
//     console.log("server is running on port 3025");
// });
